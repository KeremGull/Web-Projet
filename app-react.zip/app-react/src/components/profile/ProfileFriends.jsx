export default function ProfileFriends({id}) {
    
    return (
        <div>
            <h1>Friends</h1>
        </div>
    )
}