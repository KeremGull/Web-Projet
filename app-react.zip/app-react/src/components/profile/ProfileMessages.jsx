
export default function ProfileMessages(){
    return (
        <div>
            <h1>Messages</h1>
        </div>
    )   
}