export default function ProfileSettings(){
    return (
        <div>
            <h1>Settings</h1>
        </div>
    )      
}